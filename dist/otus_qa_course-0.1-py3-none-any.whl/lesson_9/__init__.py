from .page_object.CartPage import CartPage
from .page_object.MainPage import MainPage
from .page_object.ProductPage import ProductPage
from .page_object.CatalogPage import CatalogPage
from .page_object.AdminPage import AdminPage
