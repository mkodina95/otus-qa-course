import logging


class FileLogging(object):
    def __init__(self):
        self.logging = logging
        self.logging.basicConfig(format="%(levelname)s:%(asctime)s %(message)s",
                    filemode='w',
                    datefmt="%d-%b-%y %H:%M:%S",
                    filename="/Users/m.kodina/otus-qa-course/lesson_12/opencart_tests.log",
                    level=logging.NOTSET)

        self.logger = self.logging.getLogger('this-is-my-logger')

    def log(self, log_type, msg):
        self.logger.log(logging.INFO, "Message from browser: " + str(msg))
